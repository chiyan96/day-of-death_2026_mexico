(function(){
  'use strict';
  const KEY='mexico2026TripLogV1';
  const VALID_MEALS=['breakfast','lunch','dinner'];
  const MEAL_LABEL={breakfast:'Breakfast',lunch:'Lunch',dinner:'Dinner'};
  let undoTimer=null;

  function read(){
    try { const v=JSON.parse(localStorage.getItem(KEY)||'{}'); return v && typeof v==='object' ? v : {}; }
    catch(e){ return {}; }
  }
  function write(data){ localStorage.setItem(KEY,JSON.stringify(data)); }
  function slot(day,meal){ return String(day)+'|'+String(meal).toLowerCase(); }
  function normalize(record){
    const day=Number(record.day), meal=String(record.meal||'').toLowerCase();
    const restaurant=String(record.restaurant||'').trim();
    const rawPrice=String(record.price??'').trim();
    const price=Number(rawPrice);
    if(!Number.isInteger(day)||day<1||day>9||!VALID_MEALS.includes(meal)||!restaurant||rawPrice===''||!Number.isFinite(price)||price<0) return null;
    return {day,meal,restaurant,price};
  }
  const store={
    get(day,meal){ return read()[slot(day,meal)]||null; },
    getAll(){ return Object.values(read()).filter(Boolean).sort((a,b)=>a.day-b.day||VALID_MEALS.indexOf(a.meal)-VALID_MEALS.indexOf(b.meal)); },
    save(record){ const rec=normalize(record); if(!rec) return null; const data=read(); data[slot(rec.day,rec.meal)]=rec; write(data); return rec; },
    remove(day,meal){ const data=read(), key=slot(day,meal), old=data[key]||null; if(old){ delete data[key]; write(data); } return old; },
    restore(record){ return this.save(record); }
  };
  function formatPrice(value){ return 'MX$'+new Intl.NumberFormat('en-US',{maximumFractionDigits:2}).format(value); }
  function mealLabel(meal){ return MEAL_LABEL[meal]||meal; }

  function enhanceDayPage(){
    const m=location.pathname.match(/\/day([1-9])\/day\1\.html$/i); if(!m) return;
    const day=Number(m[1]);
    document.querySelectorAll('.item').forEach(function(item){
      const event=item.querySelector('.event'); if(!event) return;
      const clone=event.cloneNode(true); clone.querySelectorAll('.trip-log-meal-note,small,.detail,button').forEach(el=>el.remove());
      const raw=clone.textContent.trim().toLowerCase();
      const meal=VALID_MEALS.find(x=>raw===x); if(!meal) return;
      item.dataset.tripMeal=meal;
      event.querySelectorAll('.trip-log-meal-note').forEach(n=>n.remove());
      const rec=store.get(day,meal); if(!rec) return;
      const note=document.createElement('span'); note.className='trip-log-meal-note';
      const name=document.createElement('span'); name.className='trip-log-restaurant'; name.textContent=rec.restaurant;
      const price=document.createElement('span'); price.className='trip-log-price'; price.textContent=formatPrice(rec.price);
      note.append(name,price); event.appendChild(note);
    });
  }

  function initForm(){
    const form=document.getElementById('trip-log-form'); if(!form) return;
    const restaurant=form.elements.restaurant, day=form.elements.day, meal=form.elements.meal, price=form.elements.price;
    const status=document.getElementById('save-status');
    const list=document.getElementById('saved-meals-list');
    const empty=document.getElementById('saved-meals-empty');
    const cancelEdit=document.getElementById('cancel-edit');
    const saveButton=form.querySelector('.trip-save');
    const confirmBox=document.getElementById('remove-confirm');
    const confirmText=document.getElementById('remove-confirm-text');
    const confirmCancel=document.getElementById('remove-cancel');
    const confirmRemove=document.getElementById('remove-confirm-button');
    let editingKey=null, pendingRemove=null, lastDeleted=null;

    function clearStatus(){ status.replaceChildren(); }
    function resetForm(){ form.reset(); editingKey=null; saveButton.textContent='Save Meal'; cancelEdit.hidden=true; }
    function showMessage(text,undo){
      clearStatus();
      const span=document.createElement('span'); span.textContent=text; status.appendChild(span);
      if(undo){
        const btn=document.createElement('button'); btn.type='button'; btn.className='trip-undo'; btn.textContent='Undo';
        btn.addEventListener('click',function(){
          const current=store.get(undo.day,undo.meal);
          if(current){ showMessage('A newer record already exists in that meal slot.'); return; }
          store.restore(undo); lastDeleted=null; clearTimeout(undoTimer); renderList(); showMessage(`Day ${undo.day} ${mealLabel(undo.meal)} restored.`);
        });
        status.append(' ',btn);
        clearTimeout(undoTimer); undoTimer=setTimeout(function(){ lastDeleted=null; clearStatus(); },6000);
      }
    }
    function renderList(){
      const records=store.getAll(); list.replaceChildren(); empty.hidden=records.length>0;
      records.forEach(function(rec){
        const card=document.createElement('article'); card.className='saved-meal';
        const meta=document.createElement('div'); meta.className='saved-meal-meta'; meta.textContent=`Day ${rec.day} · ${mealLabel(rec.meal)}`;
        const name=document.createElement('div'); name.className='saved-meal-name'; name.textContent=rec.restaurant;
        const amount=document.createElement('div'); amount.className='saved-meal-price'; amount.textContent=formatPrice(rec.price);
        const actions=document.createElement('div'); actions.className='saved-meal-actions';
        const edit=document.createElement('button'); edit.type='button'; edit.className='trip-action'; edit.textContent='Edit';
        edit.addEventListener('click',function(){
          restaurant.value=rec.restaurant; day.value=String(rec.day); meal.value=rec.meal; price.value=String(rec.price);
          editingKey=slot(rec.day,rec.meal); saveButton.textContent='Update Meal'; cancelEdit.hidden=false; clearStatus(); restaurant.focus(); window.scrollTo({top:0,behavior:'smooth'});
        });
        const remove=document.createElement('button'); remove.type='button'; remove.className='trip-action'; remove.textContent='Remove';
        remove.addEventListener('click',function(){ pendingRemove=rec; confirmText.textContent=`Remove Day ${rec.day} ${mealLabel(rec.meal)} record?`; confirmBox.hidden=false; confirmRemove.focus(); });
        actions.append(edit,remove); card.append(meta,name,amount,actions); list.appendChild(card);
      });
    }
    function closeConfirm(){ pendingRemove=null; confirmBox.hidden=true; }
    confirmCancel.addEventListener('click',closeConfirm);
    confirmBox.addEventListener('click',function(e){ if(e.target===confirmBox) closeConfirm(); });
    confirmRemove.addEventListener('click',function(){
      if(!pendingRemove) return;
      const rec=store.remove(pendingRemove.day,pendingRemove.meal); closeConfirm();
      if(rec){ lastDeleted=rec; if(editingKey===slot(rec.day,rec.meal)) resetForm(); renderList(); showMessage(`Day ${rec.day} ${mealLabel(rec.meal)} removed.`,rec); }
    });
    cancelEdit.addEventListener('click',function(){ resetForm(); clearStatus(); });

    form.addEventListener('submit',function(e){
      e.preventDefault();
      const rec=normalize({restaurant:restaurant.value,day:day.value,meal:meal.value,price:price.value});
      if(!rec){ showMessage('Please complete all fields with valid values.'); return; }
      const newKey=slot(rec.day,rec.meal), wasEditing=!!editingKey;
      if(wasEditing && editingKey!==newKey){
        const existing=store.get(rec.day,rec.meal);
        if(existing && editingKey!==newKey){ showMessage(`Day ${rec.day} ${mealLabel(rec.meal)} already has a record. Choose another slot or remove it first.`); return; }
        const parts=editingKey.split('|'); store.remove(Number(parts[0]),parts[1]);
      }
      const saved=store.save(rec); if(!saved){ showMessage('Please complete all fields with valid values.'); return; }
      renderList(); resetForm(); showMessage(`Day ${rec.day} ${mealLabel(rec.meal)} ${wasEditing?'updated':'saved'}.`);
    });
    renderList();
  }

  document.addEventListener('DOMContentLoaded',function(){ enhanceDayPage(); initForm(); });
  window.TripLog={get:store.get,getAll:store.getAll,save:store.save,remove:store.remove,restore:store.restore};
})();
