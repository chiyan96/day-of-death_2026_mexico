(()=>{
  const KEY='mxNavTransition';
  const reduced=()=>matchMedia('(prefers-reduced-motion: reduce)').matches;
  let locked=false;
  const main=()=>document.querySelector('[data-nav-surface]')||document.querySelector('main');
  const dayLayer=()=>document.querySelector('[data-day-transition-layer]');
  const targets=(type)=>((type==='next'||type==='prev')&&dayLayer())?[dayLayer()]:[main()].filter(Boolean);
  const save=(type)=>sessionStorage.setItem(KEY,type);
  const consume=()=>{const v=sessionStorage.getItem(KEY);sessionStorage.removeItem(KEY);return v;};
  const enterMap={'flip-open':'nav-enter-flip-open','flip-close':'nav-enter-flip-close','next':'nav-enter-next','prev':'nav-enter-prev','culture':'nav-enter-culture','culture-return':'nav-enter-culture-return'};
  const exitMap={'flip-open':'nav-exit-flip-open','flip-close':'nav-exit-flip-close','next':'nav-exit-next','prev':'nav-exit-prev','culture':'nav-exit-culture','culture-return':'nav-exit-culture-return'};
  const exitNames={'flip-open':['navCardFlip','navFlipOpenOut'],'flip-close':['navFlipCloseOut'],'next':['navSlideLeftOut'],'prev':['navSlideRightOut'],'culture':['navSlideUpOut'],'culture-return':['navSlideDownOut']};
  const cleanup=()=>{locked=false;document.querySelectorAll('.nav-motion-surface,.nav-card-flip').forEach(el=>{el.classList.remove('nav-motion-surface','nav-card-flip',...Object.values(enterMap),...Object.values(exitMap));el.style.removeProperty('pointer-events')});};
  const incoming=consume();
  if(incoming&&!reduced()) requestAnimationFrame(()=>requestAnimationFrame(()=>{
    targets(incoming).forEach(s=>{s.classList.add('nav-motion-surface',enterMap[incoming]);s.addEventListener('animationend',ev=>{if(ev.target===s)s.classList.remove('nav-motion-surface',enterMap[incoming]);},{once:true});});
  }));
  const activate=(a,e)=>{
    if(!a||e?.defaultPrevented)return;
    const href=a.getAttribute('href'); if(!href||href.startsWith('#'))return;
    const type=a.dataset.transition; if(!type)return;
    if(type==='culture')sessionStorage.setItem('mxCultureReturn',a.dataset.returnHref||location.pathname);
    if(locked){e?.preventDefault();return;}
    if(reduced()){save(type);return;}
    e?.preventDefault(); locked=true; save(type);
    const animated=(type==='flip-open'&&a.classList.contains('card'))?a:targets(type)[0];
    if(!animated){location.assign(href);return;}
    const done=()=>{if(!locked)return;locked=false;clearTimeout(fallback);location.assign(href);};
    const expected=exitNames[type]||[];
    const onEnd=ev=>{if(ev.target!==animated)return;if(expected.length&& !expected.includes(ev.animationName))return;animated.removeEventListener('animationend',onEnd);done();};
    animated.addEventListener('animationend',onEnd);
    // Emergency-only failsafe: longer than every exit animation; animationend normally navigates first.
    const fallback=setTimeout(done,900);
    requestAnimationFrame(()=>requestAnimationFrame(()=>{
      if(type==='flip-open'&&a.classList.contains('card')) a.classList.add('nav-card-flip');
      else animated.classList.add('nav-motion-surface',exitMap[type]);
    }));
  };
  document.addEventListener('click',e=>{if(e.button!==0||e.metaKey||e.ctrlKey||e.shiftKey||e.altKey)return;activate(e.target.closest('a[data-transition]'),e);},{passive:false});
  const cultureBack=document.querySelector('[data-culture-back]');
  if(cultureBack){const origin=sessionStorage.getItem('mxCultureReturn');if(origin)cultureBack.setAttribute('href',origin);}
  const art=document.querySelector('.fixed-bottom-art');
  const dayNav=document.querySelector('.day-nav-flow');
  if(art||dayNav){
    const measure=()=>{
      if(art) document.documentElement.style.setProperty('--bottom-art-clearance',`${Math.ceil(art.getBoundingClientRect().height)}px`);
      if(dayNav) document.documentElement.style.setProperty('--day-nav-clearance',`${Math.ceil(dayNav.getBoundingClientRect().height)}px`);
    };
    const ro='ResizeObserver' in window?new ResizeObserver(measure):null;
    if(art) ro?.observe(art);
    if(dayNav) ro?.observe(dayNav);
    art?.addEventListener('load',measure,{once:true});
    addEventListener('resize',measure,{passive:true});
    addEventListener('orientationchange',measure,{passive:true});
    requestAnimationFrame(measure);
  }
  addEventListener('pageshow',()=>{sessionStorage.removeItem(KEY);cleanup();});
  addEventListener('pagehide',()=>{locked=false;});
})();
